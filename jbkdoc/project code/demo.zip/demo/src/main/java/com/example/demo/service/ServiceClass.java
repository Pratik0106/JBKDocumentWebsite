package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.DaoClass;

@Service
public class ServiceClass {

	@Autowired
	DaoClass dao;

	public String getData() {
		String value=dao.getData();
		return value;
	}
}
