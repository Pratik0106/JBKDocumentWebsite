package com.example.demo.dao;

import org.springframework.stereotype.Repository;

@Repository
public class DaoClass {

	public String getData() {
		String data="Hello Welcome to the Springboot!!";
		return data;
	}

	
}
