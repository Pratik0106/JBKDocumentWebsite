package com.javabykiran.SpringbootWeekendBatch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootWeekendBatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
