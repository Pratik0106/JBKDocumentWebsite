package com.jbk.SpringBootWithHibernateDemo.configuration;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;

import com.jbk.entity.Country;
import com.jbk.entity.Employee;

@Configuration
public class Hibernateconfiguration {

	@Autowired
	DataSource datasource;
	
	@Bean
	public LocalSessionFactoryBean getsessionfactory()
	{
		LocalSessionFactoryBean factorybean=new LocalSessionFactoryBean();
		//factorybean.setConfigLocation(context.getResource("classpath:hibernate.cfg.xml"));
		factorybean.setDataSource(datasource);
		factorybean.setAnnotatedClasses(Employee.class,Country.class);
		return factorybean;
	}
	
	
}
