package com.jbk.SpringBootWithHibernateDemo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jbk.SpringBootWithHibernateDemo.dao.EmployeeDao;
import com.jbk.entity.Country;
import com.jbk.entity.Employee;

@Service
public class EmployeeService {
	
	@Autowired
	EmployeeDao dao;

	public List<Employee> showallemployee() {
	
		List<Employee> listemp=dao.showallemployee();
		return listemp;
		
	}

	public List<Employee> showemployeebyid(int id) {
		List<Employee> listemp=dao.showemployeebyid(id);
		return  listemp;
	}

	public List<Employee> showemployeebyname(String name) {
		List<Employee> listemp=dao.showemployeebyname(name);
		return  listemp;
	}

	public List<Employee> showallemployeebydepartment(String department) {
		List<Employee> listemp=dao.showallemployeebydepartment(department);
		return  listemp;
	}

	public List<Employee> showallemployeebystatus(String status) {
		List<Employee> listemp=dao.showallemployeebystatus(status);
		return  listemp;
	}

	public String addEmployee(Employee emp) {
		String result=dao.addEmployee(emp);
		return result;
	}

	public String addCountry(Country ctr) {
		String result=dao.addCountry(ctr);
		return result;
		
	}

	public String deleteEmployeebyid(int id) {
		String result=dao.deleteEmployeebyid(id);
		return result;
	}

	public String deleteCountrybyid(int countryid) {
		String result=dao.deleteCountrybyid(countryid);
		return result;
	}

	public String deleteCountrybyName(String cname) {
		String result=dao.deletecountrybyName(cname);
		return result;
	}

	public List<Country> getCountrybyId(int cid) {
		List<Country>listcountry=dao.getCountrybyId(cid);
		return listcountry;
	}

	public String updateCountry(Country country) {
		String result=dao.updateCountry(country);
		return result;
	}

	public List<Employee> getemployeeBeforeToday() {
		List<Employee> listemp=dao.getemployeeBeforeToday();
		return listemp;
	}

	public String updateEmployee(Employee employee) {
		String msg=dao.updateEmployee(employee);
		
		return msg;
	}

	public List<Employee> showallemployeebycountrybyid(int cid) {
			List<Employee> listemp=dao.showallemployeebycountrybyid(cid) ;
		return listemp;
	}

	public List<Employee> showallemployeebycountryname(String cname) {
		List<Employee> listemp=dao.showallemployeebycountryname(cname) ;
		return listemp;
	}

}
