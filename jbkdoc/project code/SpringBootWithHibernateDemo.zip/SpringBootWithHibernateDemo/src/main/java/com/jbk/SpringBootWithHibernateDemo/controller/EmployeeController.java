package com.jbk.SpringBootWithHibernateDemo.controller;

import java.util.List;


import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.jbk.SpringBootWithHibernateDemo.service.EmployeeService;
import com.jbk.entity.Country;
import com.jbk.entity.Employee;
@RestController
public class EmployeeController {


	
	@Autowired
	EmployeeService service;
	//API 1-
	@RequestMapping("/showallemployee")
	public List<Employee> showallemployee()
	{
		List<Employee> listemp=service.showallemployee();
		return listemp;
	
	}
	//API 3
	
	@RequestMapping("/showemployeebyid/{id}")
	public List<Employee> showemployeebyid(@PathVariable int id)
	{
		
		List<Employee> listemp=service.showemployeebyid(id);
		return listemp;
	}
	//API 4
	@RequestMapping("/showemployeebyname/{name}")
	public List<Employee> showemployeebyname(@PathVariable String name)
	{
	
		List<Employee> listemp=service.showemployeebyname(name);
		
		return listemp;
	}
	//API 11
	@RequestMapping("/showemployeebydepartment/{department}")
	public List<Employee> showallemployeebydepartment(@PathVariable String department)
	{
	
		List<Employee> listemp=service.showallemployeebydepartment(department);
		
		return listemp;
	}
	//API 2
	@RequestMapping("/showemployeebystatus/{status}")
	public List<Employee> showallemployeebystatus(@PathVariable String status)
	{
		
		
		List<Employee> listemp=service.showallemployeebystatus(status);
		
		return listemp;
	}
	//API 6
	@PostMapping("/addemployee")
	public String addEmployee(@RequestBody Employee emp)
	{
		String result=service.addEmployee(emp);
		return result;
		
	}
	//API 7
	@PostMapping("/addcountry")
	public String addCountry(@RequestBody Country ctr)
	{
		String result=service.addCountry(ctr);
		return result;
	}
	
	//API-10
	@DeleteMapping("/deleteemployeebyid/{id}")
	public String deleteEmployeebyid(@PathVariable int id)
	{
		String result=service.deleteEmployeebyid(id);
		return result;
	}
	//API12
	@DeleteMapping("/deletecountrybyid/{countryid}")
	public String deleteCountrybyid(@PathVariable int countryid)
	{
		String result=service.deleteCountrybyid(countryid);
		return result;
	}
	//API-9
	
	@DeleteMapping("/deletecountrybyname/{cname}")
	public String deleteCountrybyName(@PathVariable String cname)
	{
		String result=service.deleteCountrybyName(cname);
		return result;
	}
	//API-13
	
	@RequestMapping("/getcountrybyid/{cid}")
	public List<Country> getCountrybyId(@PathVariable int cid)
	{
		List<Country> listcountry=service.getCountrybyId(cid);
		return listcountry;
	}
	//API-8
	@RequestMapping(value="/updatecountry", method=RequestMethod.PUT)
	public String updateCountry(@RequestBody Country country)
	{
		String result=service.updateCountry(country);
		return result;
	}
	//API 5
	@RequestMapping("/getemployeebeforetoday")
	public List<Employee> getemployeeBeforeToday()
	{
		List<Employee> listemp=service.getemployeeBeforeToday();
		return listemp;
	}
	
	//API14
	@RequestMapping(value="/updateemployee", method=RequestMethod.PUT)
	public String  updateEmployee(@RequestBody Employee employee)
	{
		String msg=service.updateEmployee(employee);
		return msg;
	}
	
	/*
	@RequestMapping("/showemployeecountit/{department}")
	public List showallemployeecountr(@PathVariable String department)
	{
		Session session=sessionFactory.openSession();
		Criteria criteria=session.createCriteria(Employee.class);
	
		criteria.add(Restrictions.eq("departmentit",department));
		criteria.setProjection(Projections.rowCount());
		List rows=criteria.list();
		System.out.println(rows);
		
		return rows;
	}
	*/
	@RequestMapping("/showemployeebbycounrtryid/{cid}")
	public List<Employee> showallemployeebycountrybyid(@PathVariable int cid)
	{
		
		List<Employee> listemp=service.showallemployeebycountrybyid(cid);
		return listemp;
		
		
		
	}
	
	@RequestMapping("/showemployeebbycounrtryname/{cname}")
	public List<Employee> showallemployeebycountryname(@PathVariable String cname)
	{
		List<Employee> listemp=service.showallemployeebycountryname(cname);
		return listemp;
	}
		
		
	/*
	@RequestMapping("/showemployeecountofstatus/{status}")
	public List showallemployeecountstatus(@PathVariable String status)
	{
		Session session=sessionFactory.openSession();
		Criteria criteria=session.createCriteria(Employee.class);
	
		criteria.add(Restrictions.eq("status",status));
		criteria.setProjection(Projections.rowCount());
		List rows=criteria.list();
		System.out.println(rows);
		
		return rows;
	}

*/
}