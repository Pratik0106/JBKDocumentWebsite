package com.jbk.SpringBootWithHibernateDemo.dao;

import java.util.Date;
import java.util.List;



import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;

import com.jbk.entity.Country;
import com.jbk.entity.Employee;

@Repository
public class EmployeeDao {

	@Autowired
	SessionFactory sessionFactory;
	
	public List<Employee> showallemployee() {
	
		Session session=sessionFactory.openSession();
		Criteria criteria=session.createCriteria(Employee.class);
		List<Employee> listemp=criteria.list();
		return listemp;
	}
	public List<Employee> showemployeebyid( int id)
	{
		Session session=sessionFactory.openSession();
		Criteria criteria=session.createCriteria(Employee.class);
		criteria.add(Restrictions.eq("id", id));
		
		List<Employee> listemp=criteria.list();
		
		return listemp;
	}
	
	public List<Employee> showemployeebyname(String name)
	{
		Session session=sessionFactory.openSession();
		Criteria criteria=session.createCriteria(Employee.class);
		criteria.add(Restrictions.eq("name", name));
		
		List<Employee> listemp=criteria.list();
		
		return listemp;
	}

	public List<Employee> showallemployeebydepartment(String department)
	{
		Session session=sessionFactory.openSession();
		Criteria criteria=session.createCriteria(Employee.class);
		criteria.add(Restrictions.eq("departmentit", department));
		
		List<Employee> listemp=criteria.list();
		
		return listemp;
	}
	
	public List<Employee> showallemployeebystatus(String status)
	{
		Session session=sessionFactory.openSession();
		Criteria criteria=session.createCriteria(Employee.class);
		criteria.add(Restrictions.eq("status",status));
		
		List<Employee> listemp=criteria.list();
		
		return listemp;
	}
	public String addEmployee(Employee emp) {
		
		System.out.println(emp.getName());
		
		Country country=new Country();
		country.setCid(emp.getCountry().getCid());
		country.setCname(emp.getCountry().getCname());
		
		
		Employee emp1=new Employee();
		
		String name=emp.getName();
		emp1.setName(name);
		emp1.setPhoneno(emp.getPhoneno());
		emp1.setDepartmentit(emp.getDepartmentit());
		emp1.setStatus(emp.getStatus());
		emp1.setCreateddtm(emp.getCreateddtm());
		emp1.setCreatedby(emp.getCreatedby());
		emp1.setUpdateddtm(emp.getUpdateddtm());
		emp1.setUpdatedby(emp.getUpdatedby());
		emp1.setCountry(country);
		
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		session.save(emp1);
		transaction.commit();
		
		return "Employee Inserted Successfully";
	}
	public String addCountry(Country ctr) {
	
		
		System.out.println(ctr.getCname());
		
		Country country=new Country();
		country.setCname(ctr.getCname());
		
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		session.save(country);
		transaction.commit();
		return "Country Added Successfully";
	}
	public String deleteEmployeebyid(int id) {
		
		System.out.println("Id"+id);
		
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		Query query=session.createQuery("delete from Employee where id=:id");
		query.setParameter("id",id);
		
		int i=query.executeUpdate();
		transaction.commit();
		if(i>0)
		{
			return "Employee deleted Succefully";
		}
		else
		{
			return "Something Went wrong";
		}
	
	}
	public String deleteCountrybyid(int countryid) {
	
		System.out.println("Country id:- "+countryid);
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		
	 Query query=session.createQuery("delete from Country where cid=:countryid");
	 query.setParameter("countryid", countryid);
	 int i=query.executeUpdate();
	 transaction.commit();
		if(i>0)
		{
			return "Country deleted Successfully!"+countryid+"country id";
		}
		else
		{
			return "Something went Wrong!";
		}
		
		
		
	}
	public String deletecountrybyName(String cname) {
		
		System.out.println("Country Name:-"+cname);
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		Query query=session.createQuery("delete from Country where cname=:cname");
		query.setParameter("cname", cname);
		int i=query.executeUpdate();
		transaction.commit();
		if(i>0)
		{
			return " "+cname+" Country deleted successfully";
		}
		else
		{
			return "something went wrong";
		}
		
		
		
	}
	public List<Country> getCountrybyId(int cid) {
		
		Session session=sessionFactory.openSession();
		Criteria criteria=session.createCriteria(Country.class);
		criteria.add(Restrictions.eq("cid", cid));
		List<Country> listcountry=criteria.list();
		return listcountry;
		
		
		
	}
	public String updateCountry(Country country) {
		System.out.println(country.getCid());
		System.out.println(country.getCname());
		String countryname=country.getCname();
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		Query query=session.createQuery("update Country set cname=:cname where cid=:cid");
		query.setParameter("cname",country.getCname());
		query.setParameter("cid", country.getCid());
		int result=query.executeUpdate();
		transaction.commit();
		if(result>0)
		{
			return "country "+countryname+" Updated Successfully";
		}
		else
		{
			return "something Went Wrong";
		}
		
		
	}
	public List<Employee> getemployeeBeforeToday() {
	
		Date date=new Date();
		System.out.println(date);
		
		
		Session session=sessionFactory.openSession();
		Query query=session.createQuery("from Employee where createddtm <:date");
		query.setParameter("date", date);
		List<Employee> listemp=query.list();
		System.out.println(listemp);
		return listemp;
	}
	public String updateEmployee(Employee employee) {
		int id=employee.getId();
		System.out.println(employee.getName());
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		Query query=session.createQuery("update Employee set name=:name ,phoneno=:phoneno,departmentit=:departmentit,status=:status,createddtm=:createddtm,createdby=:createdby,updateddtm=:updateddtm,updatedby=:updatedby,country=:country where id=:id  ");
		query.setParameter("name", employee.getName());
		query.setParameter("phoneno", employee.getPhoneno());
		query.setParameter("departmentit", employee.getDepartmentit());
		query.setParameter("status", employee.getStatus());
		query.setParameter("createddtm", employee.getCreateddtm());
		query.setParameter("createdby", employee.getCreatedby());
		query.setParameter("updateddtm", employee.getUpdateddtm());
		query.setParameter("updatedby", employee.getUpdatedby());
		query.setParameter("country", employee.getCountry());
		query.setParameter("id", employee.getId());
		int i=query.executeUpdate();
		transaction.commit();
		if(i>0)
		{
			return "Employee "+id+" Updated Successfully!";
		}
		else
		{
			return "Something went Wrong!";
		}
			
	}
	public List<Employee> showallemployeebycountrybyid(int cid) {
		 Session session=sessionFactory.openSession();
			Criteria criteria=session.createCriteria(Employee.class);
			Criteria criteria1=session.createCriteria(Country.class);
			Country country=session.get(Country.class,cid);
			System.out.println(country.getCname());
			criteria.add(Restrictions.eq("country",country));
			List<Employee> listemp=criteria.list();
			
			return listemp;
	}
	public List<Employee> showallemployeebycountryname(String cname) {
		 Session session=sessionFactory.openSession();
			Criteria criteria=session.createCriteria(Country.class);
			criteria.add(Restrictions.eq("cname",cname));
			int cid=0;
			String country_name=null;
			
			List<Country> listcountry=criteria.list();
			for(Country country:listcountry)
			{
				cid=country.getCid();
			    System.out.println(cid);
			    country_name=country.getCname();
			   System.out.println(country_name);
			}
			Country ctr=new Country();
			ctr.setCid(cid);
			ctr.setCname(cname);
			
			Criteria criteria_emp=session.createCriteria(Employee.class);
			 criteria_emp.add(Restrictions.eq("country", ctr));
			 List<Employee>listemp=criteria_emp.list();
			
			return listemp;
	}
	
	
	
}
